//����sobol ���� ���в��������Է���
#include "definition.h"
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>

#define s_number 40
#define T 500//��Ӧʱ��
#define IL2point 50
#define N 100//������
long double p[50];
FILE* fp;
FILE* out;
int isSLE;
int is_clinic_mode;
int main()
{
	//srand((unsigned)time(NULL));//�������

	double X[10];
	iniv(X, 0);//ȡ��̬
	inip();

	isSLE = 1;
	char name[50];
	double output;
	double sini = 0;
	double send = 0.1;
	int i, j, k;

	//FILE_create();

	for (i = 0; i < s_number + 2; i++)//����matrix�ļ�
	{
		sprintf(name, "E:\\project1-IL2 therapeutic window in SLE\\VS code\\sobol matrix\\matrix%d.txt", i);
		if ((fp = fopen(name, "r")) == NULL)
		{
			perror("fail to read");
			exit(1);
		}

		out = fopen("sobol width.txt", "a+");
		for (j = 0; j < N; j++)//read parameters
		{

			for (k = 0; k < s_number; k++)
			{
				fscanf(fp, "%lf", &p[k]);
				//printf("%f\n", p[k]);
			}
			//system("pause");
			output = findwindow(sini, send, IL2point);
			printf("%f\t%d\n", output, i * N + j + 1);
			fprintf(out, "%f\n", output);

		}
		fclose(fp);
		fclose(out);
		//system("pause");
	}


	return 0;
}


