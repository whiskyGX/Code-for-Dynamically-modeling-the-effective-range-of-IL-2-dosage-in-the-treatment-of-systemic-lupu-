#include "definition.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include<time.h>
#define T 1000//��Ӧʱ��
#define IL2point 100
FILE* fp;
int isSLE;
int is_clinic_mode;
long double p[41];


int main()
{
	double X[10];
	inip();//initial parameters
	p[32] = 0;
	iniv(X, 1);//initial vari. 0: all vari is zero; 1: vari. before treatment
	isSLE = 1;// select SLE model
	is_clinic_mode = 0;// select administration mode  0:normal ad.     1: simu clinic ad.

	double Agini = 0;
	double Agend = 40;
	double sini = 0;//
	double send = 0.1;
	int i = 0;
	int j = 0;


	char filetype[50];
	strcpy(filetype, "Ag0 Tcon&Treg IL2");
	char format[20];
	strcpy(format, ".txt");
	//printf("%s", IL2dose);
	strcat(filetype, format);

	//�ֲ�ͼģ��

	double IL2[IL2point];
	double Teff[IL2point];
	double dTreg[IL2point];
	double fTreg[IL2point];
	FILE* fp;
	double* pp;
	double temp_Tcon;
	double temp_Treg;

	fp = fopen(filetype, "w");
	fprintf(fp, "delta\tTcon\tTreg\n");

	pp = get_bifur(35, sini, send, IL2point);//IL-2 35
	for (i = 0;i < IL2point;i++)
	{
		temp_Tcon = *(pp + 2 * i);
		temp_Treg = *(pp + 2 * i + 1);
		//printf("%f\t%f\t%f\t%f\n", sini + (send - sini) * i / IL2point, *(pp + 2 * i), *(pp + 2 * i + 1),temp_Treg/(temp_Treg+ temp_Tcon));
		fprintf(fp, "%f\t", sini + (send - sini) * i / IL2point);//output IL-2
		fprintf(fp, "%f\t", *(pp + 2 * i));//output Tcon
		fprintf(fp, "%f\n", *(pp + 2 * i + 1));//output Treg
	}

	fclose(fp);

	return 0;
}
