#include "definition.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define T 2500//��Ӧʱ��
long double p[40];
#define IL2point 50
FILE* fp;
int isSLE;
int is_clinic_mode;

int main()
{
	double X[10];
	inip();//initial parameters
	iniv(X, 1);//initial vari. 0: all vari is zero; 1: vari. before treatment 2:HC
	isSLE = 1;// select SLE model
	double Devi=100;
	double Devi_temp;
	srand((unsigned)time(NULL));
	double p_p[2];
	for (int i = 0;i < 10000;i++)
	{
		rand();
		p[24] = (rand() / (RAND_MAX + 1.0)) * 0.05 + 0.01;//ȡ0.01 �� 0.1֮��������
		p[27] = (rand() / (RAND_MAX + 1.0)) * 400 + 100;//ȡ100 �� 1000֮��������
		is_clinic_mode = 0;
		p[35] = 0.00;// exogenous IL2
		vpass(X, T, 0);//run 
		is_clinic_mode = 1;// select administration mode  0:normal  1: He et al. clinic 2:Humrich et al.
		p[35] = 0.02;// exogenous IL2
		Devi_temp = O_O(X, T);//run 
		if (Devi_temp< Devi)
		{
			Devi = Devi_temp;
			p_p[0] = p[24];
			p_p[1] = p[27];
			printf("%f\t%f\t%f\n", Devi, p_p[0], p_p[1]);
		}
	}
	return 0;
}

