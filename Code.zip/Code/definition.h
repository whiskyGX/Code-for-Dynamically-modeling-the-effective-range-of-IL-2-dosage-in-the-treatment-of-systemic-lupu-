#pragma once


#define h 0.01

double Hill2(double x, double k, double  K);
long double F1(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK);
long double F2(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK);
long double F3(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK);
long double F4(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK);
long double F5(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK);
long double F6(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK);
long double F7(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK);
long double F8(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK);
long double F9(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK);
long double F10(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK);
double O_O(double X[], double tend);
void inip();
void iniv(double ar[], int jud);
void vpass(double X[], double tend, int isprint);
double* get_bifur(int np, double sini, double send, int point);
void rand_parameter(double r, int n_max);
double findwindow(double sini, double send, int point);
void FILE_create();
void disord(double a[], int n);
