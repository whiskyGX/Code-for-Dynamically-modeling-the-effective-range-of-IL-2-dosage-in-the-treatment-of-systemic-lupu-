#include "definition.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#define IL2point 50
#define T 500//��Ӧʱ��
#define N 100//������
//#define Agpoint 200
//#define IL2point 200
#define s_number 40
extern long double p[50];
extern FILE* fp;
extern int isSLE;
extern int is_clinic_mode;
#define M 0.5
int IL2flag = 1;
extern int noise;

double Hill2(double x, double k, double  K)
{
	//return k * x  / (x  + K );
	return k * x * x / (x * x + K * K);
	//return k * x * x * x / (x * x * x + K * K * K);
	//return k * x * x * x * x / (x * x * x * x + K * K * K * K);
}

//IRc
long double F1(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK)
{
	//printf("\t%f\n", -(p[9] + p[10])*IRc);

	return p[7] * I * (p[29] - IRc) - (p[9] + p[10]) * IRc;
}
//IRr
long double F2(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK)
{
	return p[7] * I * (p[30] - IRr) - (p[9] + p[10]) * IRr;
}
//I
long double F3(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK)
{
	double n_sec, c_sec, k_bi, k_di, k_scd, k_de, I_e;
	if (isSLE == 1)//SLE
	{
		k_bi = -p[7] * p[0] * p[1] * I * (c * (p[29] - IRc) + rd * (p[30] - IRr) + rf * (p[30] - IRr)) - p[8] * p[0] * p[1] * I * NK * (p[29] - IRk);
		k_di = p[9] * p[0] * p[1] * (IRc * c + IRr * rd + IRr * rf + IRk * NK);
		n_sec = p[12] * c * p[1];
		c_sec = p[13] * n * p[1];
	}
	else if (isSLE == 0)//healthy
	{
		k_bi = -p[7] * p[0] * p[1] * I * (c * (p[29] - IRc) + rd * (p[30] - IRr)) - p[8] * p[0] * p[1] * I * NK * (p[29] - IRk);
		k_di = p[9] * p[0] * p[1] * (IRc * c + IRr * rd + IRk * NK);
		n_sec = p[12] * 33 * c * p[1];
		c_sec = p[13] * 33 * n * p[1];
	}
	k_scd = -p[8] * I * p[31];
	k_de = -p[11] * I;
	I_e = p[35];
	//printf("\t%f\n", k_di);
	if (is_clinic_mode == 1) //He et al. 2016
	{
		if ((24 * 7 *2* M < t) && (t < 24 * 7 * 4 * M))//0-2 weeks
		{
			I_e = p[35];
		}
		else if ((24 * 7 * 6 * M < t) && (t < 24 * 7 * 8 * M))//4-6 weeks
		{
			I_e = p[35];
		}
		else if ((24 * 7 * 10 * M < t) && (t < 24 * 7 * 12 * M))//8-10 weeks
		{
			I_e = p[35];
		}
		else
		{
			I_e = 0;
		}
	}
	else if (is_clinic_mode == 2) //Humrich et al. 2019
	{
		if ((24 *14 * M < t) && (t < 24 *(14+5) * M))//1-5 days
		{
			I_e = 1.5*0.02*2;
		}
		else if ((24 * (14 + 14) * M < t) && (t < 24 * (14 + 19) * M))//15-19
		{
			I_e = 3 * 0.02*2;
		}
		else if ((24 * (14 + 35) * M < t) && (t < 24 * (14 + 40) * M))//36-40
		{
			I_e = 4.5 * 0.02*2;
		}
		else if ((24 * (14 + 56) * M < t) && (t < 24 * (14 + 61) * M))//57-61
		{
			I_e = 4.5 * 0.02*2;
		}
		else
		{
			I_e = 0;
		}
	}
	return  n_sec + c_sec + k_bi + k_di + k_scd + k_de + I_e;
}
//naive
long double F4(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK)
{
	return p[16] - p[22] * n - Hill2(a, p[14] + p[15], p[2]) * n;
}
//apc
long double F5(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK)
{


	if (isSLE == 1)//SLE
	{
		return p[17] - p[22] * a + Hill2(p[32], p[18], p[3]) * a * (1 - a / p[28]) - Hill2(a, p[24], p[33]) * rf;
	}
	else if (isSLE == 0)//healthy
	{
		return p[17] - p[22] * a + Hill2(p[32], p[18], p[3]) * a * (1 - a / p[28]) - Hill2(a, p[24], p[33]) * rd;
	}

}
//Tcon
long double F6(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK)
{
	//printf("\t%f\n", Hill2(IRc, p[19], p[4])*c*(1 - c / p[26]));


	if (isSLE == 1)//SLE
	{
		return Hill2(a, p[14], p[2]) * n + Hill2(IRc, p[19], p[4]) * c * (1 - c / p[26]) - Hill2(c, p[25], p[34]) * rf - p[22] * c;
	}
	else if (isSLE == 0)//healthy
	{
		return Hill2(a, p[14], p[2]) * n + Hill2(IRc, p[19], p[4]) * c * (1 - c / p[26]) - Hill2(c, p[25], p[34]) * rd - p[22] * c;
	}
}
//dTreg
long double F7(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK)
{
	if (isSLE == 1)//SLE
	{
		return Hill2(a, p[15], p[2]) * n + Hill2(IRr, p[20], p[5]) * rd * (1 - (rd + rf) / p[27]) - Hill2(IRr, p[21], p[6]) * rd + p[23] * rf - p[22] * rd;
	}
	else if (isSLE == 0)//healthy
	{
		return Hill2(a, p[15], p[2]) * n + Hill2(IRr, p[20], p[5]) * rd * (1 - (rd) / p[27]) - p[22] * rd;
	}
}
//fTreg
long double F8(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK)
{
	return Hill2(IRr, p[21], p[6]) * rd + Hill2(IRr, p[20], p[5]) * rf * (1 - (rd + rf) / p[27]) - p[23] * rf - p[22] * rf;
}
//IRk
long double F9(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK)
{
	//printf("\t%f\n", -(p[9] + p[10])*IRc);

	return p[8] * I * (p[29] - IRk) - (p[9] + p[10]) * IRk;
}
//NK
long double F10(long double t, long double IRc, long double IRr, long double I, long double n, long double a, long double c, long double rd, long double rf, long double IRk, long double NK)
{
	return p[36] - p[22] * NK + Hill2(IRk, p[37], p[38]) * NK * (1 - NK / p[39]);
}


void iniv(double ar[], int jud)
{
	double at[10];
	for (int j = 0; j <= 9; j++)
		at[j] = 0;
	vpass(at, T, 0);
	if (jud == 0)
	{
		for (int j = 0; j <= 9; j++)
			ar[j] = 0;
	}
	else if (jud == 1)
		//vari. before treatment
	{
		ar[0] = 0.018730;
		ar[1] = 1.872978;
		ar[2] = 0.001510;
		ar[3] = 746.383746;
		ar[4] = 179.652273;
		ar[5] = 1088.607209;
		ar[6] = 113.423424;
		ar[7] = 4.426726;
		ar[8] = 0;
		ar[9] = 60;
	}
	else if (jud == 2)	//after treatment
	{
		ar[0] = 0.134861;
		ar[1] = 13.486070;
		ar[2] = 0.018514;
		ar[3] = 821.464688;
		ar[4] = 136.912205;
		ar[5] = 648.496492;
		ar[6] = 70.941675;
		ar[7] = 96.745010;
		ar[8] = 0.134861;
		ar[9] = 100;
	}
	else if (jud == 3)	//HC
	{
		ar[0] = 0.007179;
		ar[1] = 0.717916;
		ar[2] = 0.001839;
		ar[3] = 1088.608108;
		ar[4] = 98.718829;
		ar[5] = 794.555873;
		ar[6] = 107.454826;
		ar[7] = 1.104296;
		ar[8] = 0.007179;
		ar[9] = 100;
	}
}

void inip()
{
	p[0] = 1;// alpha
	p[1] = 5e-7;//delta
	p[2] = 100;//K_a_n 
	p[3] = 1;//K_ag_a
	p[4] = 0.25;//K_ir_c
	p[5] = 15;//K_ir_r
	p[6] = 15;//K_ir_rf
	p[7] = 111.6;//k1_bi
	p[8] = p[7] / 3;//k2_bi
	p[9] = 0.83;//kdi
	p[10] = 1.7;// kde1
	p[11] = 0.1;// kde2
	p[12] = 1;// kse_c  30 normal
	p[13] = 1;// kse_n
	p[14] = 0.018;// d1
	p[15] = 0.002;// d2
	p[16] = 20;// p0n
	p[17] = 1;// p0a
	p[18] = 0.05;// pa
	p[19] = 0.05;// pc
	p[20] = 0.05;// pr
	p[21] = 0.05;// pt
	p[22] = 0.01;// q
	p[23] = 0.01;// qt
	p[24] = 0.03;// s1
	p[25] = 0.02;// s2
	p[26] = 3000;// kmc
	p[27] = 400;// kmr
	p[28] = 200;// kma
	p[29] = 0.3;// Rtc
	p[30] = 30;// Rtr
	p[31] = 1e-2;// bar Rs
	p[32] = 5;// Ag
	p[33] = 50;//K_r,a
	p[34] = 500;//K_r,c
	p[35] = 0.00;// Ie
	p[36] = 0.6;//p0k
	p[37] = 0.05;//pk
	p[38] = 0.25;//K_ir_k
	p[39] = 400;//kmk
}

void vpass(double X[], double tend, int isprint)
{
	long double g11, g12, g13, g14, g21, g22, g23, g24, g31, g32, g33, g34, g41, g42, g43, g44, g51, g52, g53, g54;
	long double g61, g62, g63, g64, g71, g72, g73, g74, g81, g82, g83, g84, g91, g92, g93, g94, g01, g02, g03, g04;

	for (double t = 0; t <= tend; t += h)
	{
		g11 = F1(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g21 = F2(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g31 = F3(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g41 = F4(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g51 = F5(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g61 = F6(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g71 = F7(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g81 = F8(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g91 = F9(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g01 = F10(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);


		g12 = F1(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g22 = F2(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g32 = F3(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g42 = F4(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g52 = F5(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g62 = F6(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g72 = F7(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g82 = F8(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g92 = F9(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g02 = F10(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);



		g13 = F1(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g23 = F2(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g33 = F3(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g43 = F4(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g53 = F5(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g63 = F6(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g73 = F7(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g83 = F8(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g93 = F9(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g03 = F10(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);

		g14 = F1(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g24 = F2(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g34 = F3(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g44 = F4(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g54 = F5(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g64 = F6(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g74 = F7(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g84 = F8(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g94 = F9(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g04 = F10(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);

		X[0] += h * (g11 + 2 * g12 + 2 * g13 + g14) / 6;
		X[1] += h * (g21 + 2 * g22 + 2 * g23 + g24) / 6;
		X[2] += h * (g31 + 2 * g32 + 2 * g33 + g34) / 6;
		X[3] += h * (g41 + 2 * g42 + 2 * g43 + g44) / 6;
		X[4] += h * (g51 + 2 * g52 + 2 * g53 + g54) / 6;
		X[5] += h * (g61 + 2 * g62 + 2 * g63 + g64) / 6;
		X[6] += h * (g71 + 2 * g72 + 2 * g73 + g74) / 6;
		X[7] += h * (g81 + 2 * g82 + 2 * g83 + g84) / 6;
		X[8] += h * (g91 + 2 * g92 + 2 * g93 + g94) / 6;
		X[9] += h * (g01 + 2 * g02 + 2 * g03 + g04) / 6;

		if (X[5] < 0)
		{
			X[5] = 0;
		}

		if (isprint == 1)
		{
			if (int(t * 100) % 100 == 0)
			{
				fprintf(fp, "%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n", t - 24 * 7*2 * M, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
				printf("%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n", t - 24 * 7*2 * M, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
			}//���ʱ��ͼ����
		}
		else if (isprint == 2)
		{
			if (int(t * 100) % (24*7*100) == 0)
			{
				fprintf(fp, "%f\n", (X[6]+X[7])/(X[5]+X[6]+X[7]));
				printf("%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n", t - 24 * 7 * M, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
			}//���ʱ��ͼ����
		}
	}
}

double O_O(double X[], double tend)
{
	long double g11, g12, g13, g14, g21, g22, g23, g24, g31, g32, g33, g34, g41, g42, g43, g44, g51, g52, g53, g54;
	long double g61, g62, g63, g64, g71, g72, g73, g74, g81, g82, g83, g84, g91, g92, g93, g94, g01, g02, g03, g04;
	int l = 0;
	double temp[8];
	double loss = 0;
	double Treg_ratio[8] = { 0,10.6,16.2,12.6,17.1,14.4,17.5,14.1 };
	for (double t = 0; t <= tend; t += h)
	{
		g11 = F1(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g21 = F2(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g31 = F3(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g41 = F4(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g51 = F5(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g61 = F6(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g71 = F7(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g81 = F8(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g91 = F9(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);
		g01 = F10(t, X[0], X[1], X[2], X[3], X[4], X[5], X[6], X[7], X[8], X[9]);


		g12 = F1(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g22 = F2(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g32 = F3(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g42 = F4(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g52 = F5(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g62 = F6(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g72 = F7(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g82 = F8(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g92 = F9(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);
		g02 = F10(t + h / 2, X[0] + h * g11 / 2, X[1] + h * g21 / 2, X[2] + h * g31 / 2, X[3] + h * g41 / 2, X[4] + h * g51 / 2, X[5] + h * g61 / 2, X[6] + h * g71 / 2, X[7] + h * g81 / 2, X[8] + h * g91 / 2, X[9] + h * g01 / 2);



		g13 = F1(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g23 = F2(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g33 = F3(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g43 = F4(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g53 = F5(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g63 = F6(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g73 = F7(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g83 = F8(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g93 = F9(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);
		g03 = F10(t + h / 2, X[0] + h * g12 / 2, X[1] + h * g22 / 2, X[2] + h * g32 / 2, X[3] + h * g42 / 2, X[4] + h * g52 / 2, X[5] + h * g62 / 2, X[6] + h * g72 / 2, X[7] + h * g82 / 2, X[8] + h * g92 / 2, X[9] + h * g02 / 2);

		g14 = F1(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g24 = F2(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g34 = F3(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g44 = F4(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g54 = F5(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g64 = F6(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g74 = F7(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g84 = F8(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g94 = F9(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);
		g04 = F10(t + h, X[0] + h * g13, X[1] + h * g23, X[2] + h * g33, X[3] + h * g43, X[4] + h * g53, X[5] + h * g63, X[6] + h * g73, X[7] + h * g83, X[8] + h * g93, X[9] + h * g03);

		X[0] += h * (g11 + 2 * g12 + 2 * g13 + g14) / 6;
		X[1] += h * (g21 + 2 * g22 + 2 * g23 + g24) / 6;
		X[2] += h * (g31 + 2 * g32 + 2 * g33 + g34) / 6;
		X[3] += h * (g41 + 2 * g42 + 2 * g43 + g44) / 6;
		X[4] += h * (g51 + 2 * g52 + 2 * g53 + g54) / 6;
		X[5] += h * (g61 + 2 * g62 + 2 * g63 + g64) / 6;
		X[6] += h * (g71 + 2 * g72 + 2 * g73 + g74) / 6;
		X[7] += h * (g81 + 2 * g82 + 2 * g83 + g84) / 6;
		X[8] += h * (g91 + 2 * g92 + 2 * g93 + g94) / 6;
		X[9] += h * (g01 + 2 * g02 + 2 * g03 + g04) / 6;

		if (X[5] < 0)
		{
			X[5] = 0;
		}


		if (int(t * 100) % (24 * 7 * 2 * 100) == 0)
		{
			temp[l] = (X[6] + X[7]) / (X[5] + X[6] + X[7]);
			//printf("%f\t%f\t%f\n", 100*temp[l], Treg_ratio[l], 100 * temp[l]- Treg_ratio[l]);
			l = l + 1;
		}//���ʱ��ͼ����

	}
	
	for (int k = 1; k < 8; k++)
	{
		loss = loss + fabs(100*temp[k] - Treg_ratio[k]);
	}
	return loss;
}

double* get_bifur(int np, double sini, double send, int point)
{

	static double IL2[500];
	static double Teff[500];
	static double Treg[500];
	//static double actTreg[IL2point];
	static double ratio[500];
	static double output[1000];
	double X[10];


	int j = 0;
	if (sini <= send)
	{
		iniv(X, 1);
		vpass(X, T, 0);
		for (j = 0, p[np] = sini; p[np] < (send); p[np] += (send - sini) / point)//IL-2����
		{
			vpass(X, T, 0);
			output[2 * j] = X[5];//Tcon
			//output[2 * j] = X[6];//dTreg
			//output[2 * j + 1] = X[9];//NK
			output[2 * j + 1] = X[6]+X[7];//Treg
	
			
														//output[2 * j] = X[12];//functional Treg
														//output[2 * j + 1] = X[12] / (X[10] + X[11]);//functional Treg ratio
														//for (int m = 0;m < 15;m++)
														//{
														//	printf("%f\t", X[m]);
														//}
														//printf("\n");

			j++;
		}
	}
	else
	{
		iniv(X, 1);
		vpass(X, T, 0);
		for (j = 0, p[np] = sini; p[np] >= send; p[np] -= (sini - send) / point)//IL-2��xia
		{

			vpass(X, T, 0);
			//IL2[j] = p[49];
			output[2 * j] = X[5];//Tcon
			output[2 * j + 1] = X[7];//fTreg
			//output[2 * j] = X[12];//functional Treg
			//output[2 * j + 1] = X[12] / (X[10] + X[11]);//functional Treg ratio
			//printf("%f\t%f\t%f\t%f\n", IL2[j], X[10], X[11], X[12]);
			//for (int j = 0; j <= 14; j++)
			//	printf("%f\n", X[j]);
			j++;
		}
	}


	return output;
	//return ratio;
}

void rand_parameter(double r, int n_max)
{
	int vari_label[15] = { 10,11,12,32,33,34,35,36,37,38,39,44,45,46,47 };//�������
	double b;
	int temp_v;
	//lhs������
	srand((unsigned)time(NULL));
	for (int m = 0; m < 15; m++)
	{
		rand();
		b = (rand() / (RAND_MAX + 1.0)) * 2 - 1;//ȡ-1 �� 1֮��������
		b = pow(r, b);
		//1/3-3֮��������
		temp_v = vari_label[m] - 1;
		p[temp_v] = p[temp_v] * b;
		//printf("%f\t%f\n", b,p[temp_v]);
	}//������� 0.1-10��Χ��
}

double findwindow(double sini, double send, int point)
{
	//double sini = 0;
	//double send = 0.04;
	double* pp;
	double Tcon[300];//��ʼTeffϸ��ռ��
	double Treg[300];
	double ratio[300];
					  //double iratio;
	pp = get_bifur(35, sini, send, point);//run bifur
	for (int m = 0; m < point; m++)
	{
		Tcon[m] = *(pp + 2 * m);//��ȡTcon����
		Treg[m] = *(pp + 2 * m+1);//��ȡTreg����
		ratio[m] = Tcon[m] / Treg[m];
	}
	double width = 0;//���ڿ���
	for (int m = 1; m < point; m++)
	{
		if (ratio[m] < 5.5)
			width = width + 1;
	}
	return width * (send - sini) / (double)point;
}

void FILE_create()
{
	srand((unsigned)time(NULL));
	double A[N][s_number];
	double B[N][s_number];
	//���ɲ����ļ�
	double a;
	double b;//���������ķ�Χ 3^-1  : 3

	int i, j, m;
	for (i = 0; i < N; i++)
	{
		for (j = 0; j < s_number; j++)
		{
			rand();
			a = (rand() / (RAND_MAX + 1.0)) * 2 - 1;
			b = (rand() / (RAND_MAX + 1.0)) * 2 - 1;//ȡ-1 �� 1֮��������
			a = pow(1.1, a);
			b = pow(1.1, b);
			A[i][j] = p[j] * a;
			B[i][j] = p[j] * b;
		}
	}//����AB ����

	double C[N][s_number];
	FILE* fp;
	char nameout[50];
	for (i = 0; i < s_number + 2; i++)
	{
		sprintf(nameout, "E:\\project1-IL2 therapeutic window in SLE\\VS code\\sobol matrix\\matrix%d.txt", i);
		//printf("%s\n", nameout);
		fp = fopen(nameout, "w");
		for (j = 0; j < N; j++)//C���������
		{
			for (m = 0; m < s_number; m++)
			{
				if (i == m)
					C[j][m] = B[j][m];
				else
					C[j][m] = A[j][m];
			}
		}
		if (i < s_number)
		{
			for (j = 0; j < N; j++)//C�����д��
			{
				for (m = 0; m < s_number; m++)
				{
					fprintf(fp, "%f\t", C[j][m]);
				}
				fprintf(fp, "\n");
			}
		}
		else if (i == s_number)
		{
			for (j = 0; j < N; j++)//A�����д��
			{
				for (m = 0; m < s_number; m++)
				{
					fprintf(fp, "%f\t", A[j][m]);
				}
				fprintf(fp, "\n");
			}
		}
		else if (i == s_number + 1)
		{
			for (j = 0; j < N; j++)//B�����д��
			{
				for (m = 0; m < s_number; m++)
				{
					fprintf(fp, "%f\t", B[j][m]);
				}
				fprintf(fp, "\n");
			}
		}
		fclose(fp);
	}
}

void disord(double a[], int n)
{
	double tmp;
	int index, i;
	srand(time(NULL));
	for (i = 0; i < n; i++)
	{
		index = rand() % (n - i) + i;
		if (index != i)
		{
			tmp = a[i];
			a[i] = a[index];
			a[index] = tmp;
		}
	}
}