#include "definition.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define T 500//��Ӧʱ��
#define para_number 40
long double p[para_number];
#define Agpoint 100
#define IL2point 50
int isSLE;
int is_clinic_mode;

FILE* fp;
FILE* fpp;
FILE* fppp;
FILE* fr;
int main()
{
	double X[10];
	iniv(X, 0);
	inip();
	//double Agini = 0;
	//double Agend = 2.5;
	double sini = 0;//
	double send = 0.1;
	isSLE = 1;//SLEmodel

	double* pp;//ָ�������ָ��
			  //
			  //
	int n_max = 5000;//����������
	srand((unsigned)time(NULL));
	rand();

	int c;
	double b[40];
	int temp_v;
	int hour;
	int minute;

	fr=fopen("lhs_5000.txt", "r");//���ļ�
	for (int n = 0; n < n_max; n++) // ����������
	{
		fp = fopen("rand_Teff_5000.txt", "a");
		fpp = fopen("rand_para_5000.txt", "a");
		fppp = fopen("rand_Treg_5000.txt", "a");

		inip();

		for (int m = 0; m < para_number; m++) //ѡ��һ�����
		{
			fscanf(fr, "%lf", &b[m]);
			//printf("%f\t", b[m]);
			p[m] = p[m] *( b[m] * 4.8 + 0.2);// �Ըñ�ŵĲ������е���
			//printf("%f\t", p[m]);
		}
		//printf("\n");
		pp = get_bifur(35, sini, send, IL2point);
		for (int i = 0; i < IL2point; i++)
		{
			fprintf(fp, "%f\t", *(pp + 2 * i));//output Teff
			fprintf(fppp, "%f\t", *(pp + 2 * i + 1));//output Treg
		}
		fprintf(fp, "\n");
		fprintf(fppp, "\n");

		for (int i = 0; i < para_number; i++)
		{
			fprintf(fpp, "%f\t", p[i]);//output para
		}
		fprintf(fpp, "\n");
		minute = (int)((n_max - n - 1) * ((double)clock() / CLOCKS_PER_SEC) / (n + 1))/60;
		printf("%d\tTime remain:%d hour %d min\n", n,minute/60, minute%60);
		fclose(fp);
		fclose(fpp);
		fclose(fppp);
	}

	fclose(fr);





	/*for (i = 0, para[45] = send; para[45] >= sini; para[45] -= (send - sini) / IL2point)//IL-2��xia
	{
	vpass(X, time);
	IL2[i] = para[45];
	Teff[i] = X[10];
	Treg[i] = X[11];
	actTreg[i] = X[12];

	fprintf(fp, "%f\t%f\t%f\t%f\n", IL2[i], Teff[i], Treg[i], actTreg[i]);
	//for (int j = 0; j <= 14; j++)
	//	printf("%f\n", X[j]);
	//i++;
	}
	*/
	//fclose(fp);

	return 0;
}

