#include "definition.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include<time.h>
#define T 500//��Ӧʱ��
int isSLE;
int is_clinic_mode;
long double p[41];

#define Agpoint 100
#define IL2point 100
FILE* fp;
FILE* fp2;
FILE* fp_d;
FILE* fp2_d;
int main()
{
	double X[10];
	iniv(X, 0);
	inip();
	double Agini = 0;//Ag range
	double Agend = 5;
	double sini = 0;//IL2 range
	double send = 0.1;
	int i = 0;
	int j = 0;
	double* pp;
	int mp = 32;// Ag
	int np = 35;//IL2
	isSLE = 1;// 0 health; 1 SLE
	//p[35] = 0.02;
	for (j = 0, p[mp] = Agini; p[mp] < Agend; p[mp] += (Agend - Agini) / Agpoint)//AgTCR
	{
		fp = fopen("SLE Ag-IL2 Tcon.txt", "a");
		fp2 = fopen("SLE Ag-IL2 Treg.txt", "a");
		iniv(X, 1);//��ʼ��X
		pp = get_bifur(np, sini, send, IL2point);
		for (i = 0; i < IL2point; i++)
		{
			//printf("%f\t", *(p+2*i));
			fprintf(fp, "%f\t", *(pp + 2 * i));//output IL2
			fprintf(fp2, "%f\t", *(pp + 2 * i + 1));//output IL2
												   //fprintf(fp, "%f\n", *(p + 2 * i + 1));//output IL2
		}
		//printf("\n");
		fprintf(fp, "\n");
		fprintf(fp2, "\n");
		/*
		fp_d = fopen("IL2_Ag_Tcon_down.txt", "a");
		fp2_d = fopen("IL2_Ag_fTreg_down.txt", "a");
		//iniv(X, 2);
		pp = get_bifur(np, send, sini, IL2point);
		for (i = 0; i < IL2point; i++)
		{
			//printf("%d\t%f\n", i,*(p+i));
			fprintf(fp_d, "%f\t", *(pp + 2 * i));//output IL2
			fprintf(fp2_d, "%f\t", *(pp + 2 * i + 1));//output IL2
													 //fprintf(fp, "%f\n", *(p + 2 * i + 1));//output IL2
		}
		fprintf(fp_d, "\n");
		fprintf(fp2_d, "\n");
		//para[33] = temp_para2;
		*/
		j++;
		fclose(fp);
		fclose(fp2);
		//fclose(fp_d);
		//fclose(fp2_d);
		printf("%f\tTime used:%.5f\n", p[mp], (double)clock() / CLOCKS_PER_SEC);

	}
	//fclose(fp);
	//fclose(fp2);
	//fclose(fp3);
	return 0;
}