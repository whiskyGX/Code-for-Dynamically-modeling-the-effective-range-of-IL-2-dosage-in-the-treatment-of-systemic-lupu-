#include "definition.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#define T 500//��Ӧʱ��
long double p[40];

#define IL2point 50
FILE* fp;
int isSLE;
int is_clinic_mode;

int main()
{
	double X[10];
	inip();//initial parameters
	iniv(X, 1);//initial vari. 0: all vari is zero; 1: vari. before treatment 2:HC
	isSLE = 1;// select SLE model
	is_clinic_mode = 0;// select administration mode  0:normal  1: He et al. clinic 2:Humrich et al.
	p[35] = 0.00;// exogenous IL2
	vpass(X, T, 0);//run 
	p[35] = 0.00;// exogenous IL2
	//p[19] = 0.153781;
	//p[20] = 0.174008;
	//p[21] = 0.192904;
	//time evolve
	//create filename
	
	char filetype[50];
	strcpy(filetype, "dose=");
	char IL2dose[20];
	memset(IL2dose, 0, sizeof(IL2dose));
	sprintf(IL2dose, "%.3f", p[35]);
	char format[20];
	strcpy(format, ".txt");
	//printf("%s", IL2dose);
	strcat(IL2dose, format);
	strcat(filetype, IL2dose);
	//printf("%s", filename);
	fp = fopen(filetype, "w");//open file to save
	vpass(X, T, 1);//run 
	fclose(fp);

	return 0;
}

